# 2FI Energie & services — site web (version finale)

A publier a la racine du depot GitHub :
- index.html : site complet, images integrees (page d ouverture : Groupes electrogenes)
- media/inspection-groupe.mp4 : video de la section Formation
- .nojekyll

Pages : #/groupes (ouverture, forfaits, formation) · #/electricite (avec securite electronique, pompes et moteurs) · #/incendie · #/location (avec accessoires et compresseurs) · #/accueil (services et realisations)
Les demandes de devis partent sur WhatsApp (+225 0140471819). Contact : contact@2f-ingnierie.com
